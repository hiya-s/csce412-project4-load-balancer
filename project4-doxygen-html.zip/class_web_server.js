var class_web_server =
[
    [ "WebServer", "class_web_server.html#a5044757cd8574d3f62a7eec5d51fb00f", null ],
    [ "assignRequest", "class_web_server.html#aa8967b848f2cbc246453957f6cbfc1a7", null ],
    [ "getCurrentRequestId", "class_web_server.html#a2b637edf4fa168e13811dcf7507e78c2", null ],
    [ "getId", "class_web_server.html#aeb7683db74eccb456592ff2f1dc211d8", null ],
    [ "isBusy", "class_web_server.html#a9a382239f638ad2b1f57621a37430874", null ],
    [ "tick", "class_web_server.html#af3fbbb5c55f04c42e951f72c6cb6e9e9", null ],
    [ "currentRequest_", "class_web_server.html#a31aab67a7c44ef85935b636698aaf9d7", null ],
    [ "id_", "class_web_server.html#a77819dbef83a428507db21aa08195fec", null ],
    [ "remainingTime_", "class_web_server.html#a0c809692294e6967985ec1bd221960c2", null ]
];