var searchData=
[
  ['finalservers_0',['finalServers',['../struct_load_balancer_stats.html#ad531a05ef65f6670e12de49c6bb4400f',1,'LoadBalancerStats::finalServers'],['../struct_simulation_stats.html#a3d3b288f4f6aece6dbda54b4e369d16b',1,'SimulationStats::finalServers']]]
];
