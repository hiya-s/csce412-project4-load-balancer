var struct_i_p_blocker_1_1_range =
[
    [ "mask", "struct_i_p_blocker_1_1_range.html#a5445d6f75b3111ab751592bbe6120c07", null ],
    [ "network", "struct_i_p_blocker_1_1_range.html#a99f70c6aaa7c6418551b9fe9131fb044", null ]
];