var searchData=
[
  ['jobtype_0',['jobType',['../struct_request.html#ad49a0f18615ea50f9a11cd2494c93044',1,'Request::jobType'],['../struct_load_balancer_1_1_job_pool.html#a4b3717476ecdc7f4f6e4f32cd223aaf3',1,'LoadBalancer::JobPool::jobType']]]
];
