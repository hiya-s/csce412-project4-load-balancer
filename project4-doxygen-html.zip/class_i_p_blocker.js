var class_i_p_blocker =
[
    [ "Range", "struct_i_p_blocker_1_1_range.html", "struct_i_p_blocker_1_1_range" ],
    [ "IPBlocker", "class_i_p_blocker.html#a63badeeed85231029928c46fdd92e6a2", null ],
    [ "IPBlocker", "class_i_p_blocker.html#ab5bd021959651214e23f68253676a972", null ],
    [ "addRange", "class_i_p_blocker.html#ac68169a92b4ddf915653f289bd4b258c", null ],
    [ "isBlocked", "class_i_p_blocker.html#ab990120b7a6a2bd174e36d30938a6bc5", null ],
    [ "ranges_", "class_i_p_blocker.html#a4235ec7bcacc463c9d81760a7d4a2552", null ]
];