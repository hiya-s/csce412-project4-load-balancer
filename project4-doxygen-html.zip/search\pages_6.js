var searchData=
[
  ['method_20and_20cycle_20design_0',['Method and cycle design',['../index.html#autotoc_md4',1,'']]]
];
