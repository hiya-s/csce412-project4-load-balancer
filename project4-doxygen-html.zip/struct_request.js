var struct_request =
[
    [ "inputIp", "struct_request.html#a94e1a3506c50a3f173c48d7feaff5f39", null ],
    [ "jobType", "struct_request.html#ad49a0f18615ea50f9a11cd2494c93044", null ],
    [ "outputIp", "struct_request.html#a3f195df754b7b377c93357c1ddc229c8", null ],
    [ "processingTime", "struct_request.html#ab2ed1f80cfac05d76ac9a7d215b3ac3c", null ],
    [ "requestId", "struct_request.html#aff3df7fd705d0c2b9290805302595b85", null ]
];