var struct_load_balancer_stats =
[
    [ "acceptedRequests", "struct_load_balancer_stats.html#af841594df30c39f19eb6e2805819334a", null ],
    [ "activeRequests", "struct_load_balancer_stats.html#a80343152a45dd930fc94f273d36f8488", null ],
    [ "blockedRequests", "struct_load_balancer_stats.html#acc11202e987542493304d139f381c62f", null ],
    [ "completedRequests", "struct_load_balancer_stats.html#a299a590292c668c888e9173a553c2b64", null ],
    [ "finalServers", "struct_load_balancer_stats.html#ad531a05ef65f6670e12de49c6bb4400f", null ],
    [ "generatedRequests", "struct_load_balancer_stats.html#ad116e57da184cfc18f31c7c934495275", null ],
    [ "initialQueueSize", "struct_load_balancer_stats.html#ad0e801c2105bcac7731d3b76351add09", null ],
    [ "initialServers", "struct_load_balancer_stats.html#ac586833882879cdd3b4725f290f2c48b", null ],
    [ "jobType", "struct_load_balancer_stats.html#af82b6bf8199ceee8ca105a04ada13def", null ],
    [ "queuedRequests", "struct_load_balancer_stats.html#a110b38b7112af36eb01ad1178676c384", null ],
    [ "serversAdded", "struct_load_balancer_stats.html#a2f9c8fa1aa372c42f1afa993d7704be6", null ],
    [ "serversRemoved", "struct_load_balancer_stats.html#ad4e56bc92c6823d1dc33feee32eefdd0", null ]
];