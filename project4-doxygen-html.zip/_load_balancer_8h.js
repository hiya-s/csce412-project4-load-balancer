var _load_balancer_8h =
[
    [ "SimulationStats", "struct_simulation_stats.html", "struct_simulation_stats" ],
    [ "LoadBalancer", "class_load_balancer.html", "class_load_balancer" ],
    [ "LoadBalancer::JobPool", "struct_load_balancer_1_1_job_pool.html", "struct_load_balancer_1_1_job_pool" ]
];