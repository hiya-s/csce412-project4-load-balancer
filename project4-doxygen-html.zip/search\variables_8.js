var searchData=
[
  ['log_5f_0',['log_',['../class_switch.html#a8b765b22765f8bd72418325ef9ea86f8',1,'Switch']]],
  ['logfile_1',['logFile',['../struct_config.html#a44a998a653da4e397ef878252595f4af',1,'Config']]]
];
