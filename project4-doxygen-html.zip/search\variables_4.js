var searchData=
[
  ['generatedrequests_0',['generatedRequests',['../struct_load_balancer_stats.html#ad116e57da184cfc18f31c7c934495275',1,'LoadBalancerStats::generatedRequests'],['../struct_simulation_stats.html#ad2c2fc13c47656db36d962afab54a863',1,'SimulationStats::generatedRequests']]],
  ['generatedrequests_5f_1',['generatedRequests_',['../class_load_balancer.html#a70e8d5da115f3ac30f6f6e15a36f537d',1,'LoadBalancer::generatedRequests_'],['../class_switch.html#accf8586db5210b394067d3474b9df80a',1,'Switch::generatedRequests_']]]
];
