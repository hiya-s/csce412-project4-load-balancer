var searchData=
[
  ['jobpool_0',['JobPool',['../struct_load_balancer_1_1_job_pool.html',1,'LoadBalancer::JobPool'],['../struct_load_balancer_1_1_job_pool.html#a33850be4e442c2ee495ac9b86320941e',1,'LoadBalancer::JobPool::JobPool()']]],
  ['jobtype_1',['jobType',['../struct_request.html#ad49a0f18615ea50f9a11cd2494c93044',1,'Request::jobType'],['../struct_load_balancer_1_1_job_pool.html#a4b3717476ecdc7f4f6e4f32cd223aaf3',1,'LoadBalancer::JobPool::jobType']]]
];
