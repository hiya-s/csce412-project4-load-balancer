var searchData=
[
  ['ipblocker_0',['IPBlocker',['../class_i_p_blocker.html#a63badeeed85231029928c46fdd92e6a2',1,'IPBlocker::IPBlocker()=default'],['../class_i_p_blocker.html#ab5bd021959651214e23f68253676a972',1,'IPBlocker::IPBlocker(const std::vector&lt; std::string &gt; &amp;ranges)']]],
  ['isblocked_1',['isBlocked',['../class_i_p_blocker.html#ab990120b7a6a2bd174e36d30938a6bc5',1,'IPBlocker']]],
  ['isbusy_2',['isBusy',['../class_web_server.html#a9a382239f638ad2b1f57621a37430874',1,'WebServer']]]
];
