var searchData=
[
  ['design_0',['design',['../index.html#autotoc_md5',1,'Documentation and design'],['../index.html#autotoc_md4',1,'Method and cycle design']]],
  ['dispatchrequests_1',['dispatchRequests',['../class_load_balancer.html#a3169481515784a094f6cdbb5c2cdb702',1,'LoadBalancer']]],
  ['documentation_20and_20design_2',['Documentation and design',['../index.html#autotoc_md5',1,'']]]
];
