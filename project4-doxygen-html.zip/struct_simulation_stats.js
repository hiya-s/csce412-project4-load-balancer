var struct_simulation_stats =
[
    [ "acceptedRequests", "struct_simulation_stats.html#aae985cd89df21aa30524a13c4c2a2833", null ],
    [ "blockedRequests", "struct_simulation_stats.html#a521e7c8f96e11265384d3ad4ce661c02", null ],
    [ "completedRequests", "struct_simulation_stats.html#a7ed7da62d80ffc4802f1b591732fcc56", null ],
    [ "cyclesCompleted", "struct_simulation_stats.html#a2ddf73f66f2aeb960cfadda481535a86", null ],
    [ "finalServers", "struct_simulation_stats.html#a3d3b288f4f6aece6dbda54b4e369d16b", null ],
    [ "generatedRequests", "struct_simulation_stats.html#ad2c2fc13c47656db36d962afab54a863", null ],
    [ "initialQueueSize", "struct_simulation_stats.html#a09ccda86dd941ba2e9f11015a1dd0232", null ],
    [ "initialServers", "struct_simulation_stats.html#a48437eb82209791e410cde64032a0261", null ],
    [ "processing", "struct_simulation_stats.html#adf1e3fd31a2bdfb8a6a700bd24861b3a", null ],
    [ "remainingQueuedRequests", "struct_simulation_stats.html#a06af6871de2223a03ff763a7aaa9b77a", null ],
    [ "requestedCycles", "struct_simulation_stats.html#aa583b074be78d80c7f75679db14724c1", null ],
    [ "requestsStillProcessing", "struct_simulation_stats.html#aca5bc7707120f4e4cea8f687cfcb17d3", null ],
    [ "serversAdded", "struct_simulation_stats.html#a1622e8127a6f0fa4ef98e99228774db2", null ],
    [ "serversRemoved", "struct_simulation_stats.html#af374c91e0d7aa4676e485f468b8b1e17", null ],
    [ "streaming", "struct_simulation_stats.html#ab99d21eeaf900a5d15a2eba696338ad6", null ]
];