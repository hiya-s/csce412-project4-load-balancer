var struct_simulation_stats =
[
    [ "acceptedRequests", "struct_simulation_stats.html#aae985cd89df21aa30524a13c4c2a2833", null ],
    [ "blockedRequests", "struct_simulation_stats.html#a521e7c8f96e11265384d3ad4ce661c02", null ],
    [ "completedRequests", "struct_simulation_stats.html#a7ed7da62d80ffc4802f1b591732fcc56", null ],
    [ "cyclesCompleted", "struct_simulation_stats.html#a2ddf73f66f2aeb960cfadda481535a86", null ],
    [ "finalServers", "struct_simulation_stats.html#a3d3b288f4f6aece6dbda54b4e369d16b", null ],
    [ "generatedRequests", "struct_simulation_stats.html#ad2c2fc13c47656db36d962afab54a863", null ],
    [ "initialQueueSize", "struct_simulation_stats.html#a09ccda86dd941ba2e9f11015a1dd0232", null ],
    [ "initialServers", "struct_simulation_stats.html#a48437eb82209791e410cde64032a0261", null ],
    [ "processingCompleted", "struct_simulation_stats.html#acf35e777848a622c3a27da9af1562139", null ],
    [ "processingQueueSize", "struct_simulation_stats.html#a113dedf7cdccd5e75346be3a7399e7b9", null ],
    [ "processingServers", "struct_simulation_stats.html#acfd8ed69901e18d56e6212ed7ae4373f", null ],
    [ "remainingQueuedRequests", "struct_simulation_stats.html#a06af6871de2223a03ff763a7aaa9b77a", null ],
    [ "requestedCycles", "struct_simulation_stats.html#aa583b074be78d80c7f75679db14724c1", null ],
    [ "requestsStillProcessing", "struct_simulation_stats.html#aca5bc7707120f4e4cea8f687cfcb17d3", null ],
    [ "serversAdded", "struct_simulation_stats.html#a1622e8127a6f0fa4ef98e99228774db2", null ],
    [ "serversRemoved", "struct_simulation_stats.html#af374c91e0d7aa4676e485f468b8b1e17", null ],
    [ "streamingCompleted", "struct_simulation_stats.html#adca11e0113ec58491a4c81e99299232b", null ],
    [ "streamingQueueSize", "struct_simulation_stats.html#abb65d1b319091d840baff44288671d23", null ],
    [ "streamingServers", "struct_simulation_stats.html#a7ce93ace8588d650e9e873af9c34266d", null ]
];