var struct_load_balancer_1_1_job_pool =
[
    [ "JobPool", "struct_load_balancer_1_1_job_pool.html#a33850be4e442c2ee495ac9b86320941e", null ],
    [ "completedRequests", "struct_load_balancer_1_1_job_pool.html#a8b7af9edc11e952fef154f9484cef61f", null ],
    [ "jobType", "struct_load_balancer_1_1_job_pool.html#a4b3717476ecdc7f4f6e4f32cd223aaf3", null ],
    [ "requests", "struct_load_balancer_1_1_job_pool.html#a3bc474a890dbe0afd214a2b677932d47", null ],
    [ "servers", "struct_load_balancer_1_1_job_pool.html#aca633edebc30f08aad2df8d66b5ca3bd", null ],
    [ "serversAdded", "struct_load_balancer_1_1_job_pool.html#aed75405cae32a1990ea6c7851911c1cb", null ],
    [ "serversRemoved", "struct_load_balancer_1_1_job_pool.html#a4e7492807e9c89eb35e298e00ddaace9", null ]
];