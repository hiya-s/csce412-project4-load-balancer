var searchData=
[
  ['jobtype_0',['jobType',['../struct_request.html#ad49a0f18615ea50f9a11cd2494c93044',1,'Request::jobType'],['../struct_load_balancer_stats.html#af82b6bf8199ceee8ca105a04ada13def',1,'LoadBalancerStats::jobType']]],
  ['jobtype_5f_1',['jobType_',['../class_load_balancer.html#a76fb674440e9cff1e88fec8719651087',1,'LoadBalancer']]]
];
