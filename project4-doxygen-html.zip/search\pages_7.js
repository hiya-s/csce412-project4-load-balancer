var searchData=
[
  ['design_0',['design',['../index.html#autotoc_md6',1,'Documentation and design'],['../index.html#autotoc_md5',1,'Method and cycle design']]],
  ['documentation_20and_20design_1',['Documentation and design',['../index.html#autotoc_md6',1,'']]]
];
