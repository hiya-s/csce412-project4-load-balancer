var searchData=
[
  ['and_20cycle_20design_0',['Method and cycle design',['../index.html#autotoc_md4',1,'']]],
  ['and_20design_1',['Documentation and design',['../index.html#autotoc_md5',1,'']]]
];
