var searchData=
[
  ['scaleservers_0',['scaleServers',['../class_load_balancer.html#a427b4ff80754405f9a8a555dba4650f1',1,'LoadBalancer']]],
  ['submitrequest_1',['submitRequest',['../class_load_balancer.html#a70d645a8eb91d17703941eeebb54f5bd',1,'LoadBalancer::submitRequest()'],['../class_switch.html#a03cf63239017480d38b6d91a50f75539',1,'Switch::submitRequest(Request request)']]],
  ['switch_2',['Switch',['../class_switch.html#af965e2246f1eb8aea83f82bab93e1708',1,'Switch']]]
];
